﻿using PR0ST0.Storage.DemoApp.Models;
using PR0ST0.Storage.DemoApp.Services;
using System;
using System.Windows;

namespace PR0ST0.Storage.DemoApp
{
    public partial class MainWindow : Window
    {
        private readonly StorageService _storage = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void OnSaveClicked(object sender, RoutedEventArgs e)
        {
            var profile = new UserProfile
            {
                Username = UsernameBox.Text,
                Age = int.TryParse(AgeBox.Text, out var age) ? age : 0
            };

            await _storage.SaveProfileAsync(profile);
            ResultText.Text = "Profile saved.";
        }

        private async void OnLoadClicked(object sender, RoutedEventArgs e)
        {
            var exists = await _storage.ProfileExistsAsync();
            if (!exists)
            {
                ResultText.Text = "No profile found.";
                return;
            }

            var profile = await _storage.LoadProfileAsync();
            if (profile != null)
            {
                UsernameBox.Text = profile.Username;
                AgeBox.Text = profile.Age.ToString();
                ResultText.Text = "Profile loaded.";
            }
        }

        private async void OnDeleteClicked(object sender, RoutedEventArgs e)
        {
            await _storage.DeleteProfileAsync();
            ResultText.Text = "Profile deleted.";
        }
    }
}
