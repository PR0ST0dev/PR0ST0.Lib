﻿namespace PR0ST0.Storage.DemoApp.Models;

public class UserProfile
{
    public string Username { get; set; }
    public int Age { get; set; }
}
