﻿using PR0ST0.Storage;
using PR0ST0.Storage.DemoApp.Models;
using System.Threading.Tasks;

namespace PR0ST0.Storage.DemoApp.Services;

public class StorageService
{
    private readonly IStorage _storage;

    public StorageService()
    {
        _storage = new FileStorage("Data");
    }

    public Task SaveProfileAsync(UserProfile profile) =>
        _storage.SaveAsync("user", profile);

    public Task<UserProfile?> LoadProfileAsync() =>
        _storage.LoadAsync<UserProfile>("user");

    public Task<bool> ProfileExistsAsync() =>
        _storage.ExistsAsync("user");

    public Task DeleteProfileAsync() =>
        _storage.DeleteAsync("user");
}
