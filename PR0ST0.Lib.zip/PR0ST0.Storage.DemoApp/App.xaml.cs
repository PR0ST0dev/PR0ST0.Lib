﻿using System.Windows;

namespace PR0ST0.Storage.DemoApp
{
    public partial class App : Application { }
}
