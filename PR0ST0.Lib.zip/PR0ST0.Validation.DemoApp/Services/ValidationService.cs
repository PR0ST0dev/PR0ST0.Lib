﻿using PR0ST0.Validation.Core;
using PR0ST0.Validation.DemoApp.Models;
using PR0ST0.Validation.DemoApp.Validators;

namespace PR0ST0.Validation.DemoApp.Services;

public class ValidationService
{
    public ValidationResult Validate(UserModel model)
    {
        var validator = new UserModelValidator();
        return validator.Validate(model);
    }
}
