﻿using PR0ST0.Validation.Core;
using PR0ST0.Validation.DemoApp.Models;

namespace PR0ST0.Validation.DemoApp.Validators;

public class UserModelValidator : Validator<UserModel>
{
    public UserModelValidator()
    {
        RuleFor("Username", x => x.Username)
            .NotEmpty()
            .MinLength(3);

        RuleFor("Age", x => x.Age)
            .GreaterThan(0)
            .LessThanOrEqualTo(120);
    }
}
