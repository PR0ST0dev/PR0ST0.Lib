﻿using System.Windows;

namespace PR0ST0.Validation.DemoApp
{
    public partial class App : Application { }
}
