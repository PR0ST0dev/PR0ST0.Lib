﻿namespace PR0ST0.Validation.DemoApp.Models;

public class UserModel
{
    public string Username { get; set; }
    public int Age { get; set; }
}
