﻿using System.ComponentModel.DataAnnotations;

namespace PR0ST0.Validation.DemoApp.Models
{
    public class UserForm
    {
        [Required]
        public string Name { get; set; }

        [Range(18, 99)]
        public int? Age { get; set; }
    }
}
