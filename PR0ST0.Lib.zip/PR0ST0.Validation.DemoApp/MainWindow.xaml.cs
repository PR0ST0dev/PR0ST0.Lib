﻿using PR0ST0.Validation.DemoApp.Models;
using PR0ST0.Validation.DemoApp.Services;
using System;
using System.Windows;

namespace PR0ST0.Validation.DemoApp
{
    public partial class MainWindow : Window
    {
        private readonly ValidationService _validationService = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void OnValidateClicked(object sender, RoutedEventArgs e)
        {
            var model = new UserModel
            {
                Username = UsernameBox.Text,
                Age = int.TryParse(AgeBox.Text, out var age) ? age : 0
            };

            var result = _validationService.Validate(model);

            if (result.IsValid)
            {
                ResultText.Text = "✅ Validation succeeded!";
            }
            else
            {
                ResultText.Text = "❌ Errors:\n" + string.Join("\n", result.Errors);
            }
        }
    }
}
