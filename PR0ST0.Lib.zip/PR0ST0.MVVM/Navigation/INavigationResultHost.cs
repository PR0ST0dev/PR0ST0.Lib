﻿namespace PR0ST0.MVVM.Navigation
{
    public interface INavigationResultHost
    {
        void SetResultCallback(System.Action<object> callback);
    }
}
