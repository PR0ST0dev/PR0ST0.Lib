﻿using System;
using System.Collections.Generic;

public interface INavigationLinkBuilder
{
    string BuildLink<TViewModel>(object parameters = null);
    bool TryParse(string link, out Type viewModelType, out Dictionary<string, object> parameters);
}
