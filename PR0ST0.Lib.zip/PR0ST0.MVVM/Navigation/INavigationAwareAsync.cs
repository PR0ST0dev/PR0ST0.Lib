﻿using System.Threading.Tasks;

public interface INavigationAwareAsync
{
    Task OnNavigatedToAsync(object parameter);
    Task OnNavigatedFromAsync();
}
