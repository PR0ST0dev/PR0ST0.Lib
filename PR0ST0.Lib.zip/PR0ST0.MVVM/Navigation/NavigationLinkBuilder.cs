﻿using PR0ST0.MVVM.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace PR0ST0.MVVM.Navigation
{
    public class NavigationLinkBuilder : INavigationLinkBuilder
    {
        private readonly Dictionary<string, Type> _routes;

        public NavigationLinkBuilder(Dictionary<string, Type> routes)
        {
            _routes = routes;
        }

        public string BuildLink<TViewModel>(object parameters = null)
        {
            var viewModelType = typeof(TViewModel);
            var routeEntry = _routes.FirstOrDefault(kvp => kvp.Value == viewModelType);
            if (string.IsNullOrEmpty(routeEntry.Key))
                throw new InvalidOperationException($"No route registered for {viewModelType.Name}");

            var basePath = routeEntry.Key;

            if (parameters == null)
                return basePath;

            var props = parameters.GetType().GetProperties();
            var query = string.Join("&", props.Select(p =>
            {
                var value = p.GetValue(parameters);
                return $"{Uri.EscapeDataString(p.Name)}={Uri.EscapeDataString(value?.ToString() ?? "")}";
            }));

            return $"{basePath}?{query}";
        }

        public bool TryParse(string link, out Type viewModelType, out Dictionary<string, object> parameters)
        {
            parameters = new Dictionary<string, object>();
            viewModelType = null;

            var parts = link.Split('?');
            var route = parts[0].Trim().ToLowerInvariant();

            if (!_routes.TryGetValue(route, out viewModelType))
                return false;

            if (parts.Length > 1)
            {
                var query = System.Web.HttpUtility.ParseQueryString(parts[1]);
                foreach (string key in query)
                {
                    parameters[key] = query[key];
                }
            }

            return true;
        }
    }

}
