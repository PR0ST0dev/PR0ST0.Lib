﻿public interface INavigationResult
{
    object Result { get; }
    void SetResult(object result);
}
