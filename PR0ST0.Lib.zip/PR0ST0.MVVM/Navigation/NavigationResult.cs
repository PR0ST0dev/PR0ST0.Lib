﻿using System.Threading.Tasks;

namespace PR0ST0.MVVM.Navigation
{
    public class NavigationResult : INavigationResult
    {
        private readonly Task<object> _resultTask;
        private object _result;

        public NavigationResult(Task<object> resultTask)
        {
            _resultTask = resultTask;
        }

        public object Result => _result;

        public async Task<object> WaitForResultAsync()
        {
            _result = await _resultTask;
            return _result;
        }

        public void SetResult(object result)
        {
            _result = result;
        }
    }
}
