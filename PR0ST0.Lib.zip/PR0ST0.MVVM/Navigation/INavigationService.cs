﻿using PR0ST0.MVVM.Base;
using PR0ST0.MVVM.Navigation;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Controls;

public interface INavigationService
{
    void RegisterFrame(string key, Frame frame);
    void Register<TViewModel, TView>() where TViewModel : ViewModelBase where TView : Page;

    void NavigateTo<TViewModel>(string frameKey, object parameter = null, TransitionType transition = TransitionType.None)
        where TViewModel : ViewModelBase;

    void NavigateToRoute(string route, string frameKey = "Main", object parameter = null, TransitionType transition = TransitionType.None);
    string GetNavigationLink<TViewModel>(object parameters = null);
    void NavigateByLink(string frameKey, string link, TransitionType transition = TransitionType.None);

    void GoBack(string frameKey);
    void Reset<TViewModel>(string frameKey) where TViewModel : ViewModelBase;
    void ClearCache();

    void AutoRegisterViewsWithAttributes(params Assembly[] assemblies);
    void RegisterRoutesFromViewModels(params Assembly[] assemblies);
    Task NavigateToAsync<TViewModel>(string frameKey, object parameter = null, TransitionType transition = TransitionType.None)
    where TViewModel : ViewModelBase;

    Task<INavigationResult> NavigateForResult<TViewModel>(string frameKey, object parameter = null, TransitionType transition = TransitionType.None)
        where TViewModel : ViewModelBase;

}
