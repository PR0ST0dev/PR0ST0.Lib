﻿using System.Collections.Generic;

namespace PR0ST0.MVVM.Navigation
{
    public class NavigationParameters : Dictionary<string, object>
    {
        public T Get<T>(string key, T defaultValue = default)
        {
            if (TryGetValue(key, out var value) && value is T t)
                return t;
            return defaultValue;
        }
    }
}
