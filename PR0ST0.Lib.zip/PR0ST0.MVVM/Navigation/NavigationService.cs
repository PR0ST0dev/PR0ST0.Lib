﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.Base;
using PR0ST0.MVVM.DI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace PR0ST0.MVVM.Navigation
{
    public enum TransitionType
    {
        None,
        Fade,
        Slide
    }

    public class NavigationService : INavigationService
    {
        private readonly IServiceResolver _resolver;
        private readonly Dictionary<string, Frame> _frames = new();
        private readonly Dictionary<Type, Type> _mappings = new();
        private readonly Dictionary<(string frameKey, Type viewModelType), Page> _cache = new();
        private readonly Dictionary<string, Type> _routes = new();
        private readonly INavigationLinkBuilder _linkBuilder;

        public NavigationService(IServiceResolver resolver)
        {
            _resolver = resolver ?? throw new ArgumentNullException(nameof(resolver));
            _linkBuilder = new NavigationLinkBuilder(_routes);
        }

        public void RegisterFrame(string key, Frame frame)
        {
            _frames[key] = frame ?? throw new ArgumentNullException(nameof(frame));
        }

        public async void NavigateTo<TViewModel>(string frameKey, object parameter = null, TransitionType transition = TransitionType.None)
            where TViewModel : ViewModelBase
        {
            await NavigateInternal(typeof(TViewModel), frameKey, parameter, transition);
        }

        public async void NavigateToRoute(string routeWithParams, string frameKey, object parameter, TransitionType transition)
        {
            var parts = routeWithParams.Split(new[] { '?' }, 2);
            var route = parts[0].Trim().ToLowerInvariant();
            var query = parts.Length > 1 ? parts[1] : "";

            if (!_routes.TryGetValue(route, out var viewModelType))
                throw new InvalidOperationException($"Route '{route}' is not registered.");

            await NavigateInternal(viewModelType, frameKey, parameter, transition, query);
        }

        public async void NavigateByLink(string frameKey, string link, TransitionType transition = TransitionType.None)
        {
            if (!_linkBuilder.TryParse(link, out var viewModelType, out var parameters))
                throw new InvalidOperationException($"Cannot parse link '{link}'.");

            var viewModel = _resolver.Resolve(viewModelType) ?? Activator.CreateInstance(viewModelType);

            foreach (var kv in parameters)
            {
                var prop = viewModelType.GetProperty(kv.Key, BindingFlags.Public | BindingFlags.Instance);
                if (prop?.CanWrite == true)
                {
                    try
                    {
                        var value = Convert.ChangeType(kv.Value, prop.PropertyType);
                        prop.SetValue(viewModel, value);
                    }
                    catch { }
                }
            }

            await NavigateInternal(viewModelType, frameKey, null, transition, null, viewModel);
        }

        private async Task NavigateInternal(
            Type viewModelType,
            string frameKey,
            object parameter,
            TransitionType transition,
            string query = null,
            object precreatedViewModel = null,
            Action<object> resultCallback = null)
        {
            if (!_frames.TryGetValue(frameKey, out var frame))
                throw new InvalidOperationException($"Frame with key '{frameKey}' is not registered.");

            if (!_mappings.TryGetValue(viewModelType, out var viewType))
                throw new InvalidOperationException($"View for {viewModelType.Name} is not registered.");

            var cacheKey = (frameKey, viewModelType);
            Page view;

            if (!_cache.TryGetValue(cacheKey, out view))
            {
                view = (Page)_resolver.Resolve(viewType);
                var viewModel = precreatedViewModel ?? _resolver.Resolve(viewModelType);

                if (query != null)
                    BindQueryParameters(viewModel, query);

                if (viewModel is INavigationResultHost host && resultCallback != null)
                    host.SetResultCallback(resultCallback);

                view.DataContext = viewModel;
                _cache[cacheKey] = view;
            }

            if (frame.Content is Page oldPage && oldPage.DataContext is INavigationAwareAsync oldAsyncAware)
                await oldAsyncAware.OnNavigatedFromAsync();

            if (view.DataContext is INavigationAware aware)
                aware.OnNavigatedTo(parameter);

            if (view.DataContext is INavigationAwareAsync asyncAware)
                await asyncAware.OnNavigatedToAsync(parameter);

            ApplyTransition(frame, view, transition);
        }

        public string GetNavigationLink<TViewModel>(object parameters = null)
        {
            return _linkBuilder.BuildLink<TViewModel>(parameters);
        }

        public void GoBack(string frameKey)
        {
            if (_frames.TryGetValue(frameKey, out var frame) && frame.CanGoBack)
                frame.GoBack();
        }

        public void Reset<TViewModel>(string frameKey) where TViewModel : ViewModelBase
        {
            _cache.Remove((frameKey, typeof(TViewModel)));
        }

        public void ClearCache() => _cache.Clear();

        public void Register<TViewModel, TView>()
            where TViewModel : ViewModelBase
            where TView : Page
            => _mappings[typeof(TViewModel)] = typeof(TView);

        public void AutoRegisterViewsWithAttributes(params Assembly[] assemblies)
        {
            foreach (var assembly in assemblies)
            {
                var views = assembly.GetTypes()
                    .Where(t => typeof(Page).IsAssignableFrom(t) && !t.IsAbstract)
                    .Where(t => t.GetCustomAttribute<ViewForAttribute>() is not null);

                foreach (var viewType in views)
                {
                    var attr = viewType.GetCustomAttribute<ViewForAttribute>();
                    var viewModelType = attr.ViewModelType;
                    if (!typeof(ViewModelBase).IsAssignableFrom(viewModelType)) continue;
                    if (_mappings.ContainsKey(viewModelType)) continue;

                    _mappings[viewModelType] = viewType;
                }
            }
        }

        public void RegisterRoutesFromViewModels(params Assembly[] assemblies)
        {
            foreach (var type in assemblies.SelectMany(a => a.GetTypes()))
            {
                if (!typeof(ViewModelBase).IsAssignableFrom(type)) continue;

                var routeAttr = type.GetCustomAttribute<RouteAttribute>();
                if (routeAttr != null && !_routes.ContainsKey(routeAttr.Route))
                    _routes[routeAttr.Route] = type;
            }
        }

        private void ApplyTransition(Frame frame, Page view, TransitionType transition)
        {
            frame.Navigate(view);

            if (!(frame.Content is UIElement content))
                return;

            switch (transition)
            {
                case TransitionType.Fade:
                    var fadeAnimation = CreateFadeAnimation();
                    content.BeginAnimation(UIElement.OpacityProperty, fadeAnimation);
                    break;

                case TransitionType.Slide:
                    var slideAnimation = CreateSlideAnimation();
                    content.BeginAnimation(FrameworkElement.MarginProperty, slideAnimation);
                    break;

                default:
                    // Нет анимации
                    break;
            }
        }

        private AnimationTimeline CreateFadeAnimation() => new DoubleAnimation
        {
            From = 0,
            To = 1,
            Duration = new Duration(TimeSpan.FromMilliseconds(300)),
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseInOut }
        };

        private AnimationTimeline CreateSlideAnimation()
        {
            var animation = new ThicknessAnimation
            {
                From = new Thickness(500, 0, -500, 0),
                To = new Thickness(0),
                Duration = TimeSpan.FromMilliseconds(400),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTargetProperty(animation, new PropertyPath(FrameworkElement.MarginProperty));
            return animation;
        }

        private void BindQueryParameters(object viewModel, string query)
        {
            if (string.IsNullOrWhiteSpace(query)) return;

            var props = viewModel.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.CanWrite).ToList();

            var kvp = System.Web.HttpUtility.ParseQueryString(query);

            foreach (var key in kvp.AllKeys)
            {
                var prop = props.FirstOrDefault(p => string.Equals(p.Name, key, StringComparison.OrdinalIgnoreCase));
                if (prop != null)
                {
                    try
                    {
                        var raw = kvp[key];
                        var converted = Convert.ChangeType(raw, prop.PropertyType);
                        prop.SetValue(viewModel, converted);
                    }
                    catch { }
                }
            }
        }

        public async Task NavigateToAsync<TViewModel>(string frameKey, object parameter = null, TransitionType transition = TransitionType.None)
            where TViewModel : ViewModelBase
        {
            await NavigateInternal(typeof(TViewModel), frameKey, parameter, transition);
        }

        public async Task<INavigationResult> NavigateForResult<TViewModel>(string frameKey, object parameter = null, TransitionType transition = TransitionType.None)
            where TViewModel : ViewModelBase
        {
            var tcs = new TaskCompletionSource<object>();

            await NavigateInternal(typeof(TViewModel), frameKey, parameter, transition, null, null, result =>
            {
                tcs.TrySetResult(result);
            });

            return new NavigationResult(tcs.Task);
        }
    }
}
