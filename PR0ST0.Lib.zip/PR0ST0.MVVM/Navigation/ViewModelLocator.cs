﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows.Controls;
using PR0ST0.MVVM.Base;

namespace PR0ST0.MVVM.Navigation
{
    public static class ViewModelLocator
    {
        public static void AutoRegister(this NavigationService nav, Assembly assembly)
        {
            var viewTypes = assembly.GetTypes()
                .Where(t => typeof(Page).IsAssignableFrom(t) && t.Name.EndsWith("Page"));

            foreach (var viewType in viewTypes)
            {
                var viewModelName = viewType.Name.Replace("Page", "ViewModel");
                var viewModelType = assembly.GetTypes()
                    .FirstOrDefault(t => t.Name == viewModelName && typeof(ViewModelBase).IsAssignableFrom(t));

                if (viewModelType != null)
                {
                    MethodInfo registerMethod = typeof(NavigationService).GetMethod("Register")
                        ?.MakeGenericMethod(viewModelType, viewType);

                    registerMethod?.Invoke(nav, null);
                }
            }
        }
    }
}
