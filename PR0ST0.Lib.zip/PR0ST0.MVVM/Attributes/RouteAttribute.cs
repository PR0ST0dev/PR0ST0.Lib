﻿using System;

namespace PR0ST0.MVVM.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class RouteAttribute : Attribute
    {
        public string Route { get; }

        public RouteAttribute(string route)
        {
            Route = route?.Trim().ToLowerInvariant();
        }
    }
}
