﻿using System;

namespace PR0ST0.MVVM.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class ViewForAttribute : Attribute
    {
        public Type ViewModelType { get; }

        public ViewForAttribute(Type viewModelType)
        {
            ViewModelType = viewModelType;
        }
    }
}
