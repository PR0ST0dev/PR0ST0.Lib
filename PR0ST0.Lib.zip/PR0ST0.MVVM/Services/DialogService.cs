﻿using System.Windows;

namespace PR0ST0.MVVM.Services
{
    public class DialogService
    {
        public void ShowMessage(string message, string title = "Сообщение")
        {
            MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public bool Confirm(string message, string title = "Подтвердите")
        {
            return MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
        }
    }
}
