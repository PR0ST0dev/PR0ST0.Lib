﻿using System;

namespace PR0ST0.MVVM.DI
{
    public interface IServiceResolver
    {
        void Register<TInterface, TImplementation>() where TImplementation : TInterface;
        void RegisterInstance<TService>(TService instance);
        TService Resolve<TService>();
        object Resolve(Type serviceType);
    }
}
