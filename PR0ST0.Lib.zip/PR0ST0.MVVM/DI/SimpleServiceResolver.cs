﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PR0ST0.MVVM.DI
{
    public class SimpleServiceResolver : IServiceResolver
    {
        private readonly Dictionary<Type, object> _instances = new();
        private readonly Dictionary<Type, Type> _registrations = new();

        public void Register<TInterface, TImplementation>() where TImplementation : TInterface
        {
            _registrations[typeof(TInterface)] = typeof(TImplementation);
            Log($"[REGISTER] {typeof(TInterface).FullName} → {typeof(TImplementation).FullName}");
        }

        public void RegisterInstance<TService>(TService instance)
        {
            _instances[typeof(TService)] = instance!;
            Log($"[REGISTER-INSTANCE] {typeof(TService).FullName}");
        }

        public TService Resolve<TService>() => (TService)Resolve(typeof(TService));

        public object Resolve(Type serviceType)
        {
            Log($"[RESOLVE] Requested: {serviceType.FullName}");

            if (_instances.TryGetValue(serviceType, out var instance))
            {
                Log($"[RESOLVE] Found instance for {serviceType.FullName}");
                return instance!;
            }

            if (!_registrations.TryGetValue(serviceType, out var implType))
            {
                if (serviceType.IsInterface || serviceType.IsAbstract)
                {
                    Log($"[ERROR] Type {serviceType.FullName} is NOT registered!");
                    throw new InvalidOperationException($"Type {serviceType.FullName} is not registered.");
                }

                Log($"[WARNING] Type {serviceType.FullName} not registered, using itself as implementation.");
                implType = serviceType;
            }

            Log($"[RESOLVE] Resolving {serviceType.FullName} → {implType.FullName}");

            var ctor = implType.GetConstructors()
                               .OrderByDescending(c => c.GetParameters().Length)
                               .FirstOrDefault();

            if (ctor == null)
                throw new InvalidOperationException($"No public constructors found for {implType.FullName}");

            var parameters = ctor.GetParameters();
            Log($"[CONSTRUCTOR] {implType.FullName} has {parameters.Length} parameters");

            var args = parameters
                        .Select(p =>
                        {
                            Log($"[RESOLVE-PARAM] {implType.FullName} → {p.ParameterType.FullName}");
                            return Resolve(p.ParameterType);
                        })
                        .ToArray();

            var created = ctor.Invoke(args);
            Log($"[CREATED] {implType.FullName} instance created.");

            _instances[serviceType] = created!;
            return created!;
        }

        private void Log(string message)
        {
            System.Diagnostics.Debug.WriteLine($"[SimpleServiceResolver] {message}");
            Console.WriteLine($"[SimpleServiceResolver] {message}"); // Для вывода в консоль при запуске из Console/WPF
        }
    }
}
