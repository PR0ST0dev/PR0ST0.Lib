﻿using System;
using System.Collections.Generic;

namespace PR0ST0.MVVM.DI
{
    public class SimpleContainer : IServiceResolver
    {
        private readonly Dictionary<Type, Type> _registrations = new();
        private readonly Dictionary<Type, object> _instances = new();

        public void Register<TInterface, TImplementation>()
            where TImplementation : TInterface
        {
            _registrations[typeof(TInterface)] = typeof(TImplementation);
        }

        public void RegisterInstance<T>(T instance)
        {
            _instances[typeof(T)] = instance;
        }

        public T Resolve<T>() => (T)Resolve(typeof(T));

        public object Resolve(Type type)
        {
            if (_instances.TryGetValue(type, out var existing))
                return existing;

            if (_registrations.TryGetValue(type, out var implementationType))
                type = implementationType;

            var constructors = type.GetConstructors();
            if (constructors.Length == 0)
                throw new InvalidOperationException($"Тип {type.FullName} не имеет доступных публичных конструкторов.");

            var ctor = constructors[0];
            var parameters = ctor.GetParameters();
            var args = new object[parameters.Length];

            for (int i = 0; i < args.Length; i++)
            {
                args[i] = Resolve(parameters[i].ParameterType);
            }

            var obj = Activator.CreateInstance(type, args);
            return obj;
        }

    }
}
