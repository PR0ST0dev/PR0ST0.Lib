﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR0ST0.MVVM.Base
{
    internal class NotifyObject
    {
    }
}
