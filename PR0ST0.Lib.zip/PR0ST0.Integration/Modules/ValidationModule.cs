using PR0ST0.Integration;
using PR0ST0.Validation.Core;

namespace PR0ST0.Integration.Modules
{
    public class ValidationModule : IIntegrationModule
    {
        public void Register(IntegrationContainer container)
        {
            var resolver = container.Resolver;
            var factory = new DefaultValidatorFactory();

            resolver.RegisterInstance<IValidatorFactory>(factory);
            container.Register(factory);
        }
    }
}
