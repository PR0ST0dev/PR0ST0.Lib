using PR0ST0.Integration;
using PR0ST0.Mediator.Core;
using PR0ST0.Mediator.DI;
using PR0ST0.Integration.Adapters;

namespace PR0ST0.Integration.Modules
{
    public class MediatorModule : IIntegrationModule
    {
        public void Register(IntegrationContainer container)
        {
            var resolver = container.Resolver;

            // ������� ��� ������������� � IServiceResolver �� Mediator
            var mediatorResolver = new MediatorResolverAdapter(resolver);
            var mediator = new PR0ST0.Mediator.Mediator(mediatorResolver);
            var adapter = new MediatorAdapter(mediator);

            resolver.RegisterInstance<IMediator>(adapter);
            container.Register(adapter);
        }
    }
}
