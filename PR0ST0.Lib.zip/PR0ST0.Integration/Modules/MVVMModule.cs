using PR0ST0.Integration;
using PR0ST0.MVVM.Navigation;
using PR0ST0.MVVM.DI;

namespace PR0ST0.Integration.Modules
{
    public class MVVMModule : IIntegrationModule
    {
        public void Register(IntegrationContainer container)
        {
            var resolver = container.Resolver;
            var navService = new NavigationService(resolver);
            resolver.RegisterInstance<INavigationService>(navService);
            container.Register(navService);
        }
    }
}
