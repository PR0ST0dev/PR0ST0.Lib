using PR0ST0.Integration;
using PR0ST0.Http.Core;

namespace PR0ST0.Integration.Modules
{
    public class HttpModule : IIntegrationModule
    {
        public void Register(IntegrationContainer container)
        {
            var resolver = container.Resolver;
            var factory = new DefaultHttpClientFactory();

            resolver.RegisterInstance<IHttpClientFactory>(factory);
            container.Register(factory);
        }
    }
}
