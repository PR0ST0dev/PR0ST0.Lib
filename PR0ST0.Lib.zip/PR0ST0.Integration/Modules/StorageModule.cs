using PR0ST0.Integration;
using PR0ST0.Storage;

namespace PR0ST0.Integration.Modules
{
    public class StorageModule : IIntegrationModule
    {
        public void Register(IntegrationContainer container)
        {
            var resolver = container.Resolver;
            var storage = new InMemoryStorage();

            resolver.RegisterInstance<IStorage>(storage);
            container.Register(storage);
        }
    }
}
