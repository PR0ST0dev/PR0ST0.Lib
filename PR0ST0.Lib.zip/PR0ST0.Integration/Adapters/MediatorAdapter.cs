using PR0ST0.Mediator.Core;
using System.Threading.Tasks;

namespace PR0ST0.Integration.Adapters
{
    public class MediatorAdapter : IMediator
    {
        private readonly PR0ST0.Mediator.Mediator _mediator;

        public MediatorAdapter(PR0ST0.Mediator.Mediator mediator)
        {
            _mediator = mediator;
        }

        public Task SendAsync(ICommand command) => _mediator.SendAsync(command);
        public Task<TResponse> SendAsync<TResponse>(IRequest<TResponse> request) => _mediator.SendAsync(request);
        public Task PublishAsync(INotification notification) => _mediator.PublishAsync(notification);
    }
}
