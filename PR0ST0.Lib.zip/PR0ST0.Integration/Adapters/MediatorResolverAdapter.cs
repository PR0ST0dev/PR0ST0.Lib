﻿using System;
using PR0ST0.Mediator.DI;

namespace PR0ST0.Integration.Adapters
{
    public class MediatorResolverAdapter : IServiceResolver
    {
        private readonly PR0ST0.MVVM.DI.IServiceResolver _inner;

        public MediatorResolverAdapter(PR0ST0.MVVM.DI.IServiceResolver inner)
        {
            _inner = inner ?? throw new ArgumentNullException(nameof(inner));
        }

        public object Resolve(Type serviceType) => _inner.Resolve(serviceType);

        public T Resolve<T>() => _inner.Resolve<T>();

        public object[] ResolveAll(Type type)
        {
            var resolved = _inner.Resolve(type);
            return resolved != null ? new[] { resolved } : Array.Empty<object>();
        }
    }
}
