using PR0ST0.Integration.Modules;

namespace PR0ST0.Integration
{
    public class IntegrationBuilder
    {
        public static void Configure(IntegrationContainer container)
        {
            container.AddModule(new MediatorModule());
            container.AddModule(new HttpModule());
            container.AddModule(new StorageModule());
            container.AddModule(new ValidationModule());
            container.AddModule(new MVVMModule());

            container.Initialize(); // �������� Register(...) � ���� �������
        }
    }
}
