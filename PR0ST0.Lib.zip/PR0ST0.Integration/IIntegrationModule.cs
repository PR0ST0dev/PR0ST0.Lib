
namespace PR0ST0.Integration
{
    public interface IIntegrationModule
    {
        void Register(IntegrationContainer container);
    }
}
