using System;
using System.Collections.Generic;
using PR0ST0.MVVM.DI;

namespace PR0ST0.Integration
{
    public class IntegrationContainer
    {
        private readonly IServiceResolver _resolver;
        private readonly Dictionary<Type, object> _services = new();
        private readonly List<IIntegrationModule> _modules = new();

        public IntegrationContainer(IServiceResolver resolver)
        {
            _resolver = resolver;
        }

        public IServiceResolver Resolver => _resolver;

        public void Register<T>(T instance) => _services[typeof(T)] = instance;

        public T Resolve<T>()
        {
            if (_services.TryGetValue(typeof(T), out var instance))
                return (T)instance;

            return _resolver.Resolve<T>();
        }

        public void AddModule(IIntegrationModule module) => _modules.Add(module);

        public void Initialize()
        {
            foreach (var module in _modules)
                module.Register(this);
        }
    }

}
