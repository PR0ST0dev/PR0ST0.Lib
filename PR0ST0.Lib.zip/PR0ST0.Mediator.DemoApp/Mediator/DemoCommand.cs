﻿using PR0ST0.Mediator.Core;

namespace PR0ST0.Mediator.DemoApp.Mediator;

public class DemoCommand : ICommand
{
    public string Text { get; }

    public DemoCommand(string text) => Text = text;
}
