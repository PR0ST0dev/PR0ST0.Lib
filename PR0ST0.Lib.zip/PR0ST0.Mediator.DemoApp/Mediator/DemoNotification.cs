﻿using PR0ST0.Mediator.Core;

namespace PR0ST0.Mediator.DemoApp.Mediator;

public class DemoNotification : INotification
{
    public string Message { get; }

    public DemoNotification(string message) => Message = message;
}
