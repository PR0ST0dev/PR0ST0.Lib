﻿using PR0ST0.Mediator.Core;

namespace PR0ST0.Mediator.DemoApp.Mediator;

public class DemoRequest : IRequest<string>
{
    public string Input { get; }

    public DemoRequest(string input) => Input = input;
}
