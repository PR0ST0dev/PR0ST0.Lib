﻿namespace PR0ST0.Mediator.DemoApp.Models;

public class DemoMessage
{
    public string Content { get; set; }

    public DemoMessage(string content) => Content = content;
}

