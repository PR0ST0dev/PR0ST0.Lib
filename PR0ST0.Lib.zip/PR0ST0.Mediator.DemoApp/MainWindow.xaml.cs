﻿using PR0ST0.Mediator.DemoApp.Mediator;
using PR0ST0.Mediator.DemoApp.Services;
using System.Windows;

namespace PR0ST0.Mediator.DemoApp;

public partial class MainWindow : Window
{
    private readonly PR0ST0.Mediator.Mediator _mediator = Bootstrapper.BuildMediator();

    public MainWindow()
    {
        InitializeComponent();
    }

    private async void SendCommand_Click(object sender, RoutedEventArgs e)
    {
        await _mediator.SendAsync(new DemoCommand(InputBox.Text));
    }

    private async void SendRequest_Click(object sender, RoutedEventArgs e)
    {
        var result = await _mediator.SendAsync(new DemoRequest(InputBox.Text));
        ResultText.Text = result;
    }

    private async void SendNotification_Click(object sender, RoutedEventArgs e)
    {
        await _mediator.PublishAsync(new DemoNotification(InputBox.Text));
        ResultText.Text = "Notification published (see Debug output)";
    }
}
