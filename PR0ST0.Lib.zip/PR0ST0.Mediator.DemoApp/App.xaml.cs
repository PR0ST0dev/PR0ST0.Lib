﻿using System.Windows;

namespace PR0ST0.Mediator.DemoApp
{
    public partial class App : Application { }
}
