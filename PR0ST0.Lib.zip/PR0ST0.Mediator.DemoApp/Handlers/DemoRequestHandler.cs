﻿using PR0ST0.Mediator.Core;
using PR0ST0.Mediator.DemoApp.Mediator;
using System.Threading.Tasks;

namespace PR0ST0.Mediator.DemoApp.Handlers;

public class DemoRequestHandler : IRequestHandler<DemoRequest, string>
{
    public Task<string> HandleAsync(DemoRequest request)
    {
        return Task.FromResult($"Response to '{request.Input}'");
    }
}
