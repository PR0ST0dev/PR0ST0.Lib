﻿using PR0ST0.Mediator.Core;
using PR0ST0.Mediator.DemoApp.Mediator;
using System.Threading.Tasks;
using System.Windows;

namespace PR0ST0.Mediator.DemoApp.Handlers;

public class DemoCommandHandler : ICommandHandler<DemoCommand>
{
    public Task HandleAsync(DemoCommand command)
    {
        MessageBox.Show($"Command received: {command.Text}", "Command");
        return Task.CompletedTask;
    }
}
