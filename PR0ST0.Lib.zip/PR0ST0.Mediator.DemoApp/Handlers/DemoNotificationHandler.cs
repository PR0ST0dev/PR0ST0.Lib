﻿using PR0ST0.Mediator.Core;
using PR0ST0.Mediator.DemoApp.Mediator;
using System.Diagnostics;
using System.Threading.Tasks;

namespace PR0ST0.Mediator.DemoApp.Handlers;

public class DemoNotificationHandler : INotificationHandler<DemoNotification>
{
    public Task HandleAsync(DemoNotification notification)
    {
        Debug.WriteLine($"[Notification] {notification.Message}");
        return Task.CompletedTask;
    }
}
