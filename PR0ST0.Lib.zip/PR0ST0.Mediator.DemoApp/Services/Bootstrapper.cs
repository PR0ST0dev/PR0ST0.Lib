﻿using PR0ST0.Mediator;
using PR0ST0.Mediator.DemoApp.Handlers;
using PR0ST0.Mediator.DemoApp.Mediator;
using PR0ST0.Mediator.Core;
using PR0ST0.Mediator.DI;
using PR0ST0.Mediator.Pipeline;

namespace PR0ST0.Mediator.DemoApp.Services;

public static class Bootstrapper
{
    public static PR0ST0.Mediator.Mediator BuildMediator()
    {
        var resolver = new SimpleResolver();

        // Регистрация хендлеров по интерфейсам
        resolver.Register<ICommandHandler<DemoCommand>>(() => new DemoCommandHandler());
        resolver.Register<IRequestHandler<DemoRequest, string>>(() => new DemoRequestHandler());
        resolver.RegisterMany<INotificationHandler<DemoNotification>>(() => new DemoNotificationHandler());

        // Поведение (логгирование)
        var behaviors = new object[]
        {
            new LoggingBehavior<IRequest<string>, string>()
        };

        return new PR0ST0.Mediator.Mediator(resolver, behaviors);
    }
}
