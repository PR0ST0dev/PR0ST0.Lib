using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace PR0ST0.Storage;

public class FileStorage : IStorage
{
    private readonly string _basePath;
    private readonly JsonSerializerSettings _jsonSettings;

    public FileStorage(string basePath)
    {
        _basePath = basePath ?? throw new ArgumentNullException(nameof(basePath));
        Directory.CreateDirectory(_basePath);

        _jsonSettings = new JsonSerializerSettings
        {
            TypeNameHandling = TypeNameHandling.Auto,
            Formatting = Formatting.Indented
        };
    }

    private string GetFilePath(string key) => Path.Combine(_basePath, $"{key}.json");

    public Task SaveAsync<T>(string key, T data)
    {
        var json = JsonConvert.SerializeObject(data, _jsonSettings);
        var path = GetFilePath(key);
        File.WriteAllText(path, json, Encoding.UTF8);
        return Task.CompletedTask;
    }

    public Task<T?> LoadAsync<T>(string key)
    {
        var path = GetFilePath(key);
        if (!File.Exists(path)) return Task.FromResult<T?>(default);

        var json = File.ReadAllText(path, Encoding.UTF8);
        var result = JsonConvert.DeserializeObject<T>(json, _jsonSettings);
        return Task.FromResult(result);
    }

    public Task<bool> ExistsAsync(string key)
    {
        var path = GetFilePath(key);
        return Task.FromResult(File.Exists(path));
    }

    public Task DeleteAsync(string key)
    {
        var path = GetFilePath(key);
        if (File.Exists(path))
            File.Delete(path);
        return Task.CompletedTask;
    }
}
