using System.Collections.Generic;
using System.Threading.Tasks;

namespace PR0ST0.Storage;

public class CompositeStorage : IStorage
{
    private readonly List<IStorage> _storages;

    public CompositeStorage(params IStorage[] storages)
    {
        _storages = new List<IStorage>(storages);
    }

    public async Task SaveAsync<T>(string key, T data)
    {
        foreach (var storage in _storages)
            await storage.SaveAsync(key, data);
    }

    public async Task<T?> LoadAsync<T>(string key)
    {
        foreach (var storage in _storages)
        {
            if (await storage.ExistsAsync(key))
                return await storage.LoadAsync<T>(key);
        }
        return default;
    }

    public async Task<bool> ExistsAsync(string key)
    {
        foreach (var storage in _storages)
        {
            if (await storage.ExistsAsync(key))
                return true;
        }
        return false;
    }

    public async Task DeleteAsync(string key)
    {
        foreach (var storage in _storages)
            await storage.DeleteAsync(key);
    }
}
