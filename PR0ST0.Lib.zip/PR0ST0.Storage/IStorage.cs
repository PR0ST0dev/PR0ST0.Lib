using System.Threading.Tasks;

namespace PR0ST0.Storage;

public interface IStorage
{
    Task SaveAsync<T>(string key, T data);
    Task<T?> LoadAsync<T>(string key);
    Task<bool> ExistsAsync(string key);
    Task DeleteAsync(string key);
}
