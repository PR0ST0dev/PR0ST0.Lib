using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace PR0ST0.Storage;

public class InMemoryStorage : IStorage
{
    private readonly ConcurrentDictionary<string, object> _store = new();

    public Task SaveAsync<T>(string key, T data)
    {
        _store[key] = data!;
        return Task.CompletedTask;
    }

    public Task<T?> LoadAsync<T>(string key)
    {
        _store.TryGetValue(key, out var value);
        return Task.FromResult(value is T t ? t : default);
    }

    public Task<bool> ExistsAsync(string key)
    {
        return Task.FromResult(_store.ContainsKey(key));
    }

    public Task DeleteAsync(string key)
    {
        _store.TryRemove(key, out _);
        return Task.CompletedTask;
    }
}
