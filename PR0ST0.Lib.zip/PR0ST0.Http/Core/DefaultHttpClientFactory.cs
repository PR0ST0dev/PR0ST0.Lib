using System.Net.Http;

namespace PR0ST0.Http.Core
{
    public class DefaultHttpClientFactory : IHttpClientFactory
    {
        public HttpClient CreateClient() => new HttpClient();
    }
}