using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace PR0ST0.Http.Core;

public interface IHttpRequestBuilder
{
    IHttpRequestBuilder WithMethod(HttpMethod method);
    IHttpRequestBuilder WithUrl(string url);
    IHttpRequestBuilder WithHeader(string key, string value);
    IHttpRequestBuilder WithQueryParameter(string key, object value);
    IHttpRequestBuilder WithBody(object body);
    IHttpRequestBuilder WithTimeout(TimeSpan timeout);
    IHttpRequestBuilder WithRetry(int count, TimeSpan delay);
    Task<HttpResponseMessage> SendAsync(CancellationToken cancellationToken = default);
    Task<T> SendAsync<T>(CancellationToken cancellationToken = default);
}