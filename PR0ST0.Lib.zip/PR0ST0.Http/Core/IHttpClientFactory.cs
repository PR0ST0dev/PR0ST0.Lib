using System.Net.Http;

namespace PR0ST0.Http.Core
{
    public interface IHttpClientFactory
    {
        HttpClient CreateClient();
    }
}