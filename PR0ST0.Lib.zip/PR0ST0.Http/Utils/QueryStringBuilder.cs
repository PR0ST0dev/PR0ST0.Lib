using System.Collections.Generic;
using System.Web;

namespace PR0ST0.Http.Utils;

public static class QueryStringBuilder
{
    public static string Build(string existingQuery, Dictionary<string, object> parameters)
    {
        var query = HttpUtility.ParseQueryString(existingQuery ?? "");
        foreach (var kv in parameters)
            query[kv.Key] = kv.Value?.ToString();
        return query.ToString();
    }
}