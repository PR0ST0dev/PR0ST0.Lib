using System.Net.Http;

namespace PR0ST0.Http.Mocks;

public interface IMockHttpHandler
{
    bool TryMock(HttpRequestMessage request, out HttpResponseMessage response);
}