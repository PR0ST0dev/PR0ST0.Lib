﻿using System.Net.Http;

namespace PR0ST0.Http.Mocks;

public class NullMockHttpHandler : IMockHttpHandler
{
    public bool TryMock(HttpRequestMessage request, out HttpResponseMessage response)
    {
        response = null;
        return false;
    }
}
