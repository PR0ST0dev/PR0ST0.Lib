﻿using System.Net.Http;

namespace PR0ST0.Http.Logging;

public class NullHttpLogger : IHttpLogger
{
    public void Log(string message) { }

    public void LogRequest(HttpRequestMessage request) { }

    public void LogResponse(HttpResponseMessage response) { }
}
