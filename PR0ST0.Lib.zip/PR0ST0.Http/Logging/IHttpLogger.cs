using System.Net.Http;

namespace PR0ST0.Http.Logging;

public interface IHttpLogger
{
    void Log(string message);
    void LogRequest(HttpRequestMessage request);
    void LogResponse(HttpResponseMessage response);
}