using Newtonsoft.Json;
using PR0ST0.Http.Serialization;
using System.Net.Http;
using System.Threading.Tasks;

public class NewtonsoftJsonSerializer : IHttpSerializer
{
    public async Task<T> DeserializeAsync<T>(HttpResponseMessage response)
    {
        var json = await response.Content.ReadAsStringAsync();
        return JsonConvert.DeserializeObject<T>(json);
    }

    public HttpContent Serialize(object data)
    {
        var json = JsonConvert.SerializeObject(data);
        return new StringContent(json, System.Text.Encoding.UTF8, "application/json");
    }
}
