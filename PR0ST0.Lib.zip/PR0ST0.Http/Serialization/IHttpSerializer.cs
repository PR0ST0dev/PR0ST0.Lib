using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace PR0ST0.Http.Serialization;

public interface IHttpSerializer
{
    HttpContent Serialize(object body);
    Task<T> DeserializeAsync<T>(HttpResponseMessage response);
}