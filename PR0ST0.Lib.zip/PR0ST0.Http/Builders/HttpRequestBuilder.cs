using PR0ST0.Http.Core;
using PR0ST0.Http.Logging;
using PR0ST0.Http.Mocks;
using PR0ST0.Http.Serialization;
using PR0ST0.Http.Utils;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace PR0ST0.Http.Builders;

public class HttpRequestBuilder : IHttpRequestBuilder
{
    private readonly HttpClient _client;
    private readonly IHttpLogger _logger;
    private readonly IHttpSerializer _serializer;
    private readonly IMockHttpHandler _mockHandler;
    private readonly HttpRequestMessage _request = new();
    private readonly Dictionary<string, object> _queryParams = new();
    private object _body;
    private TimeSpan? _timeout;
    private int _retryCount = 0;
    private TimeSpan _retryDelay = TimeSpan.Zero;

    public HttpRequestBuilder(HttpClient client, IHttpLogger logger, IHttpSerializer serializer, IMockHttpHandler mockHandler)
    {
        _client = client;
        _logger = logger;
        _serializer = serializer;
        _mockHandler = mockHandler;
    }

    public IHttpRequestBuilder WithMethod(HttpMethod method)
    {
        _request.Method = method;
        return this;
    }

    public IHttpRequestBuilder WithUrl(string url)
    {
        _request.RequestUri = new Uri(url, UriKind.RelativeOrAbsolute);
        return this;
    }

    public IHttpRequestBuilder WithHeader(string key, string value)
    {
        _request.Headers.TryAddWithoutValidation(key, value);
        return this;
    }

    public IHttpRequestBuilder WithQueryParameter(string key, object value)
    {
        _queryParams[key] = value;
        return this;
    }

    public IHttpRequestBuilder WithBody(object body)
    {
        _body = body;
        return this;
    }

    public IHttpRequestBuilder WithTimeout(TimeSpan timeout)
    {
        _timeout = timeout;
        return this;
    }

    public IHttpRequestBuilder WithRetry(int count, TimeSpan delay)
    {
        _retryCount = count;
        _retryDelay = delay;
        return this;
    }

    public async Task<HttpResponseMessage> SendAsync(CancellationToken cancellationToken = default)
    {
        ApplyQueryParameters();

        if (_mockHandler != null && _mockHandler.TryMock(_request, out var mockResponse))
        {
            _logger?.Log("Mock response used.");
            return mockResponse;
        }

        if (_body != null)
            _request.Content = _serializer.Serialize(_body);

        using var cts = _timeout.HasValue
            ? CancellationTokenSource.CreateLinkedTokenSource(cancellationToken)
            : null;

        if (_timeout.HasValue)
            cts.CancelAfter(_timeout.Value);

        var finalToken = cts?.Token ?? cancellationToken;

        HttpResponseMessage response = null;
        for (int attempt = 0; attempt <= _retryCount; attempt++)
        {
            try
            {
                _logger?.LogRequest(_request);
                response = await _client.SendAsync(_request, finalToken);
                _logger?.LogResponse(response);
                response.EnsureSuccessStatusCode();
                return response;
            }
            catch (Exception ex) when (attempt < _retryCount)
            {
                _logger?.Log($"Attempt {attempt + 1} failed: {ex.Message}");
                await Task.Delay(_retryDelay, finalToken);
            }
        }

        return response;
    }

    public async Task<T> SendAsync<T>(CancellationToken cancellationToken = default)
    {
        var response = await SendAsync(cancellationToken);
        return await _serializer.DeserializeAsync<T>(response);
    }

    private void ApplyQueryParameters()
    {
        if (_queryParams.Count == 0 || _request.RequestUri == null)
            return;

        var uri = new UriBuilder(_request.RequestUri);
        var query = QueryStringBuilder.Build(uri.Query, _queryParams);
        uri.Query = query;
        _request.RequestUri = uri.Uri;
    }
}