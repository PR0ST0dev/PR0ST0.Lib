namespace PR0ST0.Validation.Core;

public interface IValidator<T>
{
    ValidationResult Validate(T instance);
}