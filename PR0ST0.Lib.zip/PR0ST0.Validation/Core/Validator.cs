using System;
using System.Collections.Generic;

namespace PR0ST0.Validation.Core;

public abstract class Validator<T> : IValidator<T>
{
    private readonly List<object> _rules = new();

    protected RuleBuilder<T, TProperty> RuleFor<TProperty>(string name, Func<T, TProperty> property)
    {
        var rule = new RuleBuilder<T, TProperty>(name, property);
        _rules.Add(rule);
        return rule;
    }

    public ValidationResult Validate(T instance)
    {
        var result = new ValidationResult();

        foreach (var rule in _rules)
        {
            var method = rule.GetType().GetMethod("Validate");
            method?.Invoke(rule, new object[] { instance, result });
        }

        return result;
    }
}