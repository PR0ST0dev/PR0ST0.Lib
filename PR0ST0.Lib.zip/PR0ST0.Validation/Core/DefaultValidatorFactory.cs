using System;

namespace PR0ST0.Validation.Core
{
    public class DefaultValidatorFactory : IValidatorFactory
    {
        public IValidator<T> CreateValidator<T>()
        {
            var type = typeof(IValidator<T>);
            return (IValidator<T>)Activator.CreateInstance(type);
        }
    }
}