namespace PR0ST0.Validation.Core
{
    public interface IValidatorFactory
    {
        IValidator<T> CreateValidator<T>();
    }
}