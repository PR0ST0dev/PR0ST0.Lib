﻿namespace PR0ST0.Validation.Core
{
    public class ValidationContext
    {
        private readonly ValidationResult _result;

        public ValidationContext(ValidationResult result)
        {
            _result = result;
        }

        public void AddError(string propertyName, string errorMessage)
        {
            _result.AddFailure(propertyName, errorMessage);
        }
    }
}
