using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PR0ST0.Validation.Core;

public class RuleBuilder<T, TProperty>
{
    private readonly List<Action<TProperty, ValidationContext>> _validators = new();

    internal string Name { get; }
    internal Func<T, TProperty> Property { get; }

    public RuleBuilder(string name, Func<T, TProperty> property)
    {
        Name = name;
        Property = property;
    }

    /// <summary>
    /// ��������� ������� ���������.
    /// </summary>
    public RuleBuilder<T, TProperty> AddRule(Action<TProperty, ValidationContext> rule)
    {
        _validators.Add(rule);
        return this;
    }

    internal void Validate(T instance, ValidationResult result)
    {
        var value = Property(instance);
        var context = new ValidationContext(result);
        foreach (var validator in _validators)
        {
            validator(value, context);
        }
    }
}
