using System.Collections.Generic;
using System.Linq;

namespace PR0ST0.Validation.Core;

public class ValidationResult
{
    public List<ValidationFailure> Errors { get; } = new();

    public bool IsValid => !Errors.Any();

    public void AddFailure(string property, string message)
    {
        Errors.Add(new ValidationFailure(property, message));
    }
}