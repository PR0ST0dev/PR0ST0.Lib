﻿using System;

namespace PR0ST0.Validation.Core;

public static class ValidationExtensions
{
    public static RuleBuilder<T, string> NotEmpty<T>(this RuleBuilder<T, string> builder)
    {
        builder.AddRule((value, ctx) =>
        {
            if (string.IsNullOrWhiteSpace(value))
                ctx.AddError(builder.Name, "cannot be empty");
        });
        return builder;
    }

    public static RuleBuilder<T, string> MinLength<T>(this RuleBuilder<T, string> builder, int min)
    {
        builder.AddRule((value, ctx) =>
        {
            if (value == null || value.Length < min)
                ctx.AddError(builder.Name, $"must be at least {min} characters");
        });
        return builder;
    }

    public static RuleBuilder<T, int> GreaterThan<T>(this RuleBuilder<T, int> builder, int min)
    {
        builder.AddRule((value, ctx) =>
        {
            if (value <= min)
                ctx.AddError(builder.Name, $"must be greater than {min}");
        });
        return builder;
    }

    public static RuleBuilder<T, int> LessThanOrEqualTo<T>(this RuleBuilder<T, int> builder, int max)
    {
        builder.AddRule((value, ctx) =>
        {
            if (value > max)
                ctx.AddError(builder.Name, $"must be less than or equal to {max}");
        });
        return builder;
    }

    // Можно добавить другие по аналогии: EqualTo, NotNull, Matches и т.д.
}
