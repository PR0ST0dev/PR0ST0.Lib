﻿using System.Windows;

namespace PR0ST0.MVVM.DemoApp
{
    public partial class App : Application
    {
        private AppBootstrapper _bootstrapper;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            _bootstrapper = new AppBootstrapper();
            _bootstrapper.Run();
        }
    }
}
