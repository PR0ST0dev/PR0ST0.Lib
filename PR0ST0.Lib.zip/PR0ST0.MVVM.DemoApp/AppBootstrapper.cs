﻿using PR0ST0.MVVM.DemoApp.ViewModels;
using PR0ST0.MVVM.DemoApp.Views;
using PR0ST0.MVVM.DI;
using PR0ST0.MVVM.Navigation;
using System.Reflection;

namespace PR0ST0.MVVM.DemoApp
{
    public class AppBootstrapper
    {
        public static IServiceResolver Container { get; private set; }
        public static INavigationService Navigator { get; private set; }

        public void Run()
        {
            var container = new SimpleContainer();

            // Регистрируем контейнер как IServiceResolver
            container.RegisterInstance<IServiceResolver>(container);
            Container = container;

            // Регистрируем NavigationService с внедрением зависимостей
            var navigator = new NavigationService(container);
            container.RegisterInstance<INavigationService>(navigator);
            Navigator = navigator;

            // Регистрируем ViewModels
            container.Register<HomeViewModel, HomeViewModel>();
            container.Register<SettingsViewModel, SettingsViewModel>();
            container.Register<ProfileViewModel, ProfileViewModel>();
            container.Register<ModalViewModel, ModalViewModel>();
            container.Register<DetailsViewModel, DetailsViewModel>();

            // Регистрируем Views
            navigator.Register<HomeViewModel, HomePage>();
            navigator.Register<SettingsViewModel, SettingsPage>();
            navigator.Register<ProfileViewModel, ProfilePage>();
            navigator.Register<ModalViewModel, ModalPage>();
            navigator.Register<DetailsViewModel, DetailsPage>();

            // Автоскан маршрутов и ViewFor
            var assembly = Assembly.GetExecutingAssembly();
            navigator.RegisterRoutesFromViewModels(assembly);
            navigator.AutoRegisterViewsWithAttributes(assembly);

            // Создаем MainWindow и регистрируем Frame
            var mainWindow = new MainWindow();
            navigator.RegisterFrame("Main", mainWindow.MainFrame);
            mainWindow.Show();

            // Начальная навигация
            _ = navigator.NavigateToAsync<HomeViewModel>("Main");
        }
    }
}
