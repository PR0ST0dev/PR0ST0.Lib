﻿using System.Windows;
using System.Windows.Controls;
using PR0ST0.MVVM.DemoApp.ViewModels;
using PR0ST0.MVVM.Navigation;

namespace PR0ST0.MVVM.DemoApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Регистрация фреймов
            AppBootstrapper.Navigator.RegisterFrame("Main", MainFrame);
            AppBootstrapper.Navigator.RegisterFrame("Child", ChildFrame);

            // Начальная страница
            AppBootstrapper.Navigator.NavigateTo<HomeViewModel>("Main");
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            AppBootstrapper.Navigator.NavigateToRoute("home", "Main", transition: TransitionType.None);
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            // deep linking с query параметрами
            AppBootstrapper.Navigator.NavigateToRoute("settings?Theme=Dark&Volume=75", "Main", transition: TransitionType.Fade);
        }

        private void Profile_Click(object sender, RoutedEventArgs e)
        {
            // передаём параметры через query строку
            AppBootstrapper.Navigator.NavigateToRoute("profile?UserId=42&ShowDetails=true", "Main", transition: TransitionType.Slide);
        }

        private async void Modal_Click(object sender, RoutedEventArgs e)
        {
            var result = await AppBootstrapper.Navigator.NavigateForResult<ModalViewModel>("Main");
            ResultText.Text = result?.ToString() ?? "(null)";
        }

        private void ChildFrame_Click(object sender, RoutedEventArgs e)
        {
            // отображение вложенного фрейма и навигация в него
            ChildFrameContainer.Visibility = Visibility.Visible;
            AppBootstrapper.Navigator.NavigateToRoute("details?ItemId=123", "Child");
        }

        private void Fade_Click(object sender, RoutedEventArgs e)
        {
            AppBootstrapper.Navigator.NavigateToRoute("settings?Theme=Light", "Main", transition: TransitionType.Fade);
        }

        private void Slide_Click(object sender, RoutedEventArgs e)
        {
            AppBootstrapper.Navigator.NavigateToRoute("profile?UserId=1", "Main", transition: TransitionType.Slide);
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            AppBootstrapper.Navigator.Reset<HomeViewModel>("Main");
            MessageBox.Show("Кэш HomeViewModel сброшен");
        }
    }
}
