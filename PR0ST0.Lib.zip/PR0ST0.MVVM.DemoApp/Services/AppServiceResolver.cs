﻿using System;
using System.Collections.Generic;
using System.Linq;
using PR0ST0.MVVM.DI;

namespace PR0ST0.MVVM.DemoApp.Services
{
    public class AppServiceResolver : IServiceResolver
    {
        private readonly Dictionary<Type, Type> _registrations = new();
        private readonly Dictionary<Type, object> _instances = new();

        public void Register<TInterface, TImplementation>()
            where TImplementation : TInterface
        {
            _registrations[typeof(TInterface)] = typeof(TImplementation);
        }

        public void RegisterInstance<TService>(TService instance)
        {
            _instances[typeof(TService)] = instance!;
        }

        public TService Resolve<TService>()
        {
            return (TService)Resolve(typeof(TService));
        }

        public object Resolve(Type serviceType)
        {
            if (_instances.TryGetValue(serviceType, out var existing))
                return existing;

            if (_registrations.TryGetValue(serviceType, out var implementationType))
                serviceType = implementationType;

            var ctor = serviceType.GetConstructors().FirstOrDefault();
            if (ctor == null)
                throw new InvalidOperationException($"No public constructor found for type {serviceType.FullName}");

            var args = ctor.GetParameters()
                           .Select(p => Resolve(p.ParameterType))
                           .ToArray();

            var instance = Activator.CreateInstance(serviceType, args)!;
            _instances[serviceType] = instance;
            return instance;
        }
    }
}
