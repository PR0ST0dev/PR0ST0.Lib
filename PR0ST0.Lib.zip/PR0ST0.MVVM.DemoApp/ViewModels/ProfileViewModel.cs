﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.Base;
using PR0ST0.MVVM.Commands;
using PR0ST0.MVVM.Navigation;
using System.Windows.Input;

namespace PR0ST0.MVVM.DemoApp.ViewModels
{
    [Route("profile")]
    public class ProfileViewModel : ViewModelBase, INavigationAware
    {
        private readonly INavigationService _navigation;

        public ICommand NavigateToDetailsCommand { get; }

        public ProfileViewModel(INavigationService navigation)
        {
            _navigation = navigation;

            NavigateToDetailsCommand = new RelayCommand(_ =>
                _navigation.NavigateTo<DetailsViewModel>("DetailsFrame"));
        }

        public void OnNavigatedTo(object parameter) { }

        public void OnNavigatedFrom() { }
    }
}
