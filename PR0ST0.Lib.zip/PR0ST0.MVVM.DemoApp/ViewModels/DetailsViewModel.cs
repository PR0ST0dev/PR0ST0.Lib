﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.Base;
using PR0ST0.MVVM.Navigation;

namespace PR0ST0.MVVM.DemoApp.ViewModels
{
    [Route("details")]
    public class DetailsViewModel : ViewModelBase, INavigationAware
    {
        private string _info = "Это вложенная страница деталей";

        public string Info
        {
            get => _info;
            set => SetProperty(ref _info, value);
        }

        public void OnNavigatedTo(object parameter) { }

        public void OnNavigatedFrom() { }
    }
}
