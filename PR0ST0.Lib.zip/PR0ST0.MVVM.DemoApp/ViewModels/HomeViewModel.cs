﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.Base;
using PR0ST0.MVVM.Commands;
using PR0ST0.MVVM.Navigation;
using System.Windows.Input;

namespace PR0ST0.MVVM.DemoApp.ViewModels
{
    [Route("home")]
    public class HomeViewModel : ViewModelBase, INavigationAware
    {
        private readonly INavigationService _navigation;
        private string _showMessage;

        public ICommand NavigateToSettingsCommand { get; }
        public ICommand NavigateToProfileCommand { get; }
        public ICommand OpenModalCommand { get; }

        public string ShowMessage
        {
            get => _showMessage;
            set => SetProperty(ref _showMessage, value);
        }

        public HomeViewModel(INavigationService navigation)
        {
            _navigation = navigation;

            NavigateToSettingsCommand = new RelayCommand(_ =>
                _navigation.NavigateToRoute("settings?theme=Light&volume=30", "Main"));

            NavigateToProfileCommand = new RelayCommand(_ =>
                _navigation.NavigateToRoute("profile", "Main"));

            OpenModalCommand = new RelayCommand(async _ =>
            {
                var result = await _navigation.NavigateForResult<ModalViewModel>("Main", null, TransitionType.Fade);
                if (result.Result is string msg)
                    ShowMessage = $"Результат модального окна: {msg}";

            });
        }

        public void OnNavigatedTo(object parameter) { }

        public void OnNavigatedFrom() { }
    }
}
