﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.Base;
using PR0ST0.MVVM.Commands;
using System;
using System.Windows.Input;

namespace PR0ST0.MVVM.DemoApp.ViewModels
{
    [Route("modal")]
    public class ModalViewModel : ViewModelBase
    {
        private string _input;

        public ICommand CloseCommand { get; }

        public string Input
        {
            get => _input;
            set => SetProperty(ref _input, value);
        }

        // Этот колбэк устанавливается через INavigationResultHost
        public Action<object> CloseWithResult { get; set; }

        public ModalViewModel()
        {
            CloseCommand = new RelayCommand(_ =>
            {
                CloseWithResult?.Invoke(Input ?? "Нет данных");
            });
        }
    }
}
