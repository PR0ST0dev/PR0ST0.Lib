﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.Base;
using PR0ST0.MVVM.Navigation;

namespace PR0ST0.MVVM.DemoApp.ViewModels
{
    [Route("settings")]
    public class SettingsViewModel : ViewModelBase, INavigationAware
    {
        private string _theme;
        private int _volume;

        public string Theme
        {
            get => _theme;
            set => SetProperty(ref _theme, value);
        }

        public int Volume
        {
            get => _volume;
            set => SetProperty(ref _volume, value);
        }

        public void OnNavigatedTo(object parameter)
        {
            if (parameter is NavigationParameters query)
            {
                Theme = query.Get<string>("theme");
                Volume = query.Get<int>("volume");
            }
        }

        public void OnNavigatedFrom() { }
    }
}
