﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.DemoApp.ViewModels;
using PR0ST0.MVVM.Navigation;
using System;
using System.Windows.Controls;

namespace PR0ST0.MVVM.DemoApp.Views
{
    [ViewFor(typeof(ModalViewModel))]
    public partial class ModalPage : Page, INavigationResultHost
    {
        public ModalPage(ModalViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }

        public void SetResultCallback(Action<object> callback)
        {
            if (DataContext is ModalViewModel vm)
                vm.CloseWithResult = callback;
        }
    }
}
