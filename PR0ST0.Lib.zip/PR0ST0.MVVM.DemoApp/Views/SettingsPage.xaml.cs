﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.DemoApp.ViewModels;
using System.Windows.Controls;

namespace PR0ST0.MVVM.DemoApp.Views
{
    [ViewFor(typeof(SettingsViewModel))]
    public partial class SettingsPage : Page
    {
        public SettingsPage(SettingsViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }
    }
}
