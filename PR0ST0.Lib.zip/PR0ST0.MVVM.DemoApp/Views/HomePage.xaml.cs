﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.DemoApp.ViewModels;
using System.Windows.Controls;

namespace PR0ST0.MVVM.DemoApp.Views
{
    [ViewFor(typeof(HomeViewModel))]
    public partial class HomePage : Page
    {
        public HomePage(HomeViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }
    }
}
