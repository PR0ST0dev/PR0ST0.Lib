﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.DemoApp.ViewModels;
using System.Windows.Controls;

namespace PR0ST0.MVVM.DemoApp.Views
{
    [ViewFor(typeof(ProfileViewModel))]
    public partial class ProfilePage : Page
    {
        public ProfilePage(ProfileViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }
    }
}
