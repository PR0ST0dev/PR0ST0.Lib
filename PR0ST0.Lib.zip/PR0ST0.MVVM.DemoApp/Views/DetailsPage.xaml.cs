﻿using PR0ST0.MVVM.Attributes;
using PR0ST0.MVVM.DemoApp.ViewModels;
using System.Windows.Controls;

namespace PR0ST0.MVVM.DemoApp.Views
{
    [ViewFor(typeof(DetailsViewModel))]
    public partial class DetailsPage : Page
    {
        public DetailsPage(DetailsViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }
    }
}
