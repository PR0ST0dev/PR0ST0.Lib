﻿using PR0ST0.Http.DemoApp.Services;
using System;
using System.Windows;

namespace PR0ST0.Http.DemoApp
{
    public partial class MainWindow : Window
    {
        private readonly DemoHttpService _httpService = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ResultText.Text = "Загрузка...";
                if (int.TryParse(PostIdBox.Text, out int id))
                {
                    var post = await _httpService.GetPostAsync(id);
                    ResultText.Text = $"#{post.Id}: {post.Title}\n\n{post.Body}";
                }
                else
                {
                    ResultText.Text = "Введите корректный ID.";
                }
            }
            catch (Exception ex)
            {
                ResultText.Text = $"Ошибка: {ex.Message}";
            }
        }
    }
}
