﻿using PR0ST0.Http.Builders;
using PR0ST0.Http.DemoApp.Models;
using PR0ST0.Http.Logging;
using PR0ST0.Http.Mocks;
using PR0ST0.Http.Serialization;
using System.Net.Http;
using System.Threading.Tasks;

namespace PR0ST0.Http.DemoApp.Services
{
    public class DemoHttpService
    {
        private readonly HttpClient _client = new();
        private readonly IHttpLogger _logger = new NullHttpLogger();
        private readonly IHttpSerializer _serializer = new NewtonsoftJsonSerializer();
        private readonly IMockHttpHandler _mockHandler = new NullMockHttpHandler();

        public async Task<Post> GetPostAsync(int id)
        {
            var builder = new HttpRequestBuilder(_client, _logger, _serializer, _mockHandler)
                .WithMethod(HttpMethod.Get)
                .WithUrl($"https://jsonplaceholder.typicode.com/posts/{id}");

            var response = await builder.SendAsync();
            return await _serializer.DeserializeAsync<Post>(response);
        }
    }
}
