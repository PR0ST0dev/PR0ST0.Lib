using System;

namespace PR0ST0.Mediator.DI
{
    public interface IServiceResolver
    {
        object Resolve(Type type);
        T Resolve<T>();
        object[] ResolveAll(Type type);
    }
}