using System;
using System.Collections.Generic;
using System.Linq;

namespace PR0ST0.Mediator.DI
{
    public class SimpleResolver : IServiceResolver
    {
        private readonly Dictionary<Type, Func<object>> _registrations = new();
        private readonly Dictionary<Type, List<Func<object>>> _multi = new();

        public void Register<T>(Func<T> factory)
        {
            _registrations[typeof(T)] = () => factory();
        }

        public void RegisterMany<T>(Func<T> factory)
        {
            if (!_multi.ContainsKey(typeof(T)))
                _multi[typeof(T)] = new List<Func<object>>();
            _multi[typeof(T)].Add(() => factory());
        }

        public object Resolve(Type type)
        {
            if (_registrations.TryGetValue(type, out var factory))
                return factory();

            if (!type.IsAbstract && !type.IsInterface)
                return Activator.CreateInstance(type);

            throw new InvalidOperationException($"Type {type.FullName} is not registered and cannot be instantiated.");
        }


        public T Resolve<T>() => (T)Resolve(typeof(T));

        public object[] ResolveAll(Type type) =>
            _multi.TryGetValue(type, out var list) ? list.Select(f => f()).ToArray() : Array.Empty<object>();
    }
}