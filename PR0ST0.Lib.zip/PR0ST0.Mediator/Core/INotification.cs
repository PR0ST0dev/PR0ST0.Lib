namespace PR0ST0.Mediator.Core
{
    public interface INotification { }
}