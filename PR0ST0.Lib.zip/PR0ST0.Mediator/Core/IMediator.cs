using System.Threading.Tasks;
namespace PR0ST0.Mediator.Core
{
    public interface IMediator
    {
        Task SendAsync(ICommand command);
        Task<TResponse> SendAsync<TResponse>(IRequest<TResponse> request);
        Task PublishAsync(INotification notification);
    }
}