using System.Threading.Tasks;

namespace PR0ST0.Mediator.Core
{
    public interface INotificationHandler<TNotification> where TNotification : INotification
    {
        Task HandleAsync(TNotification notification);
    }
}