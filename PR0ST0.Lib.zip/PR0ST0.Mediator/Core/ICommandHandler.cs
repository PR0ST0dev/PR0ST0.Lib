using System.Threading.Tasks;

namespace PR0ST0.Mediator.Core
{
    public interface ICommandHandler<TCommand> where TCommand : ICommand
    {
        Task HandleAsync(TCommand command);
    }
}