using System;
using System.Threading.Tasks;

namespace PR0ST0.Mediator.Pipeline
{
    public class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    {
        public async Task<TResponse> HandleAsync(TRequest request, RequestHandlerDelegate<TResponse> next)
        {
            Console.WriteLine($">>> Handling {typeof(TRequest).Name}");
            var response = await next();
            Console.WriteLine($"<<< Handled {typeof(TRequest).Name}");
            return response;
        }
    }
}