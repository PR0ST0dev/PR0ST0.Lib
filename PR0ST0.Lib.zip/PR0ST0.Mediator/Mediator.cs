using PR0ST0.Mediator.Core;
using PR0ST0.Mediator.DI;
using PR0ST0.Mediator.Pipeline;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PR0ST0.Mediator
{
    public class Mediator
    {
        private readonly IServiceResolver _resolver;
        private readonly IEnumerable<object> _behaviors;

        public Mediator(IServiceResolver resolver, IEnumerable<object> behaviors = null)
        {
            _resolver = resolver;
            _behaviors = behaviors ?? Enumerable.Empty<object>();
        }

        public Task<TResponse> SendAsync<TResponse>(IRequest<TResponse> request)
        {
            var handlerType = typeof(IRequestHandler<,>).MakeGenericType(request.GetType(), typeof(TResponse));
            dynamic handler = _resolver.Resolve(handlerType);

            RequestHandlerDelegate<TResponse> next = () => handler.HandleAsync((dynamic)request);

            foreach (var behavior in _behaviors.OfType<IPipelineBehavior<IRequest<TResponse>, TResponse>>().Reverse())
            {
                var current = next;
                next = () => behavior.HandleAsync(request, current);
            }

            return next();
        }

        public Task SendAsync(ICommand command)
        {
            var handlerType = typeof(ICommandHandler<>).MakeGenericType(command.GetType());
            dynamic handler = _resolver.Resolve(handlerType);
            return handler.HandleAsync((dynamic)command);
        }

        public async Task PublishAsync(INotification notification)
        {
            var handlerType = typeof(INotificationHandler<>).MakeGenericType(notification.GetType());
            var handlers = _resolver.ResolveAll(handlerType);

            foreach (dynamic handler in handlers)
                await handler.HandleAsync((dynamic)notification);
        }
    }
}