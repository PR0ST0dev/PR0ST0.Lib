﻿using System.Windows.Controls;
using PR0ST0.MVVM.Attributes;
using PR0ST0.Integration.DemoApp.ViewModels;

namespace PR0ST0.Integration.DemoApp.Views
{
    [ViewFor(typeof(MainViewModel))]
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
