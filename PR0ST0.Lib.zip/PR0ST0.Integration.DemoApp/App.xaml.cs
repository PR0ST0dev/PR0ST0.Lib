﻿using System.Windows;

namespace PR0ST0.Integration.DemoApp
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // ВАЖНО: регистрация и инициализация ВСЕХ сервисов, включая IStorage
            AppBootstrapper.Run();

            // Открытие главного окна
            var window = new MainWindow();
            window.Show();
        }
    }
}
