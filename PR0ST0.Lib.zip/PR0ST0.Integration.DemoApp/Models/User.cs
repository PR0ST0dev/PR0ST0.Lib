﻿namespace PR0ST0.Integration.DemoApp.Models
{
    public class User
    {
        public string Name { get; set; }
    }
}
