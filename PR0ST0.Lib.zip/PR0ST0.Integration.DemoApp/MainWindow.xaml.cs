﻿using System.Windows;
using PR0ST0.Integration.DemoApp.ViewModels;

namespace PR0ST0.Integration.DemoApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Навигация — уже безопасна, т.к. вызов после AppBootstrapper.Run()
            AppBootstrapper.Navigation.RegisterFrame("Main", MainFrame);
            AppBootstrapper.Navigation.NavigateTo<MainViewModel>("Main");
        }
    }
}
