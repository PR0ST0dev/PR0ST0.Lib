﻿using PR0ST0.MVVM.Base;
using PR0ST0.MVVM.Commands;
using PR0ST0.Storage;
using System.Threading.Tasks;
using System.Windows.Input;
using PR0ST0.Integration.DemoApp.Services;

namespace PR0ST0.Integration.DemoApp.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly FakeUserService _userService;
        private readonly IStorage _storage;

        public string Message => "Welcome to PR0ST0.Integration Demo!";
        public ICommand LoadUserCommand { get; }

        private string _loadedUser;
        public string LoadedUser
        {
            get => _loadedUser;
            set => SetProperty(ref _loadedUser, value);
        }

        public MainViewModel(FakeUserService userService, IStorage storage)
        {
            _userService = userService;
            _storage = storage;
            LoadUserCommand = new AsyncRelayCommand(LoadUserAsync);
        }

        private async Task LoadUserAsync()
        {
            var user = await _userService.GetUserAsync();
            await _storage.SaveAsync("last_user", user.Name);
            LoadedUser = $"User Loaded: {user.Name}";
        }
    }
}
