﻿using System.Threading.Tasks;
using PR0ST0.Integration.DemoApp.Models;

namespace PR0ST0.Integration.DemoApp.Services
{
    public class FakeUserService
    {
        public Task<User> GetUserAsync()
        {
            return Task.FromResult(new User { Name = "John Doe" });
        }
    }
}
