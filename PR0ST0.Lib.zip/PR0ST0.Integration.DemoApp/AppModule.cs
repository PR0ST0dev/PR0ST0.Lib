﻿using PR0ST0.Integration.DemoApp.Services;
using PR0ST0.Integration.DemoApp.ViewModels;
using PR0ST0.MVVM.DI;
using PR0ST0.Storage;
using System;

namespace PR0ST0.Integration.DemoApp
{
    public class AppModule : IIntegrationModule
    {
        public void Register(IntegrationContainer container)
        {
            Console.WriteLine("[AppModule] Register() called");

            var resolver = container.Resolver;

            resolver.Register<IStorage, InMemoryStorage>();
            resolver.Register<FakeUserService, FakeUserService>();
            resolver.Register<MainViewModel, MainViewModel>();

            Console.WriteLine("[AppModule] Registration complete");
        }
    }

}
