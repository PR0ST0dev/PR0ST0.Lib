﻿using PR0ST0.Integration;
using PR0ST0.Integration.Modules;
using PR0ST0.MVVM.DI;
using PR0ST0.MVVM.Navigation;
using System;
using System.Reflection;

namespace PR0ST0.Integration.DemoApp
{
    public static class AppBootstrapper
    {
        public static IntegrationContainer Container { get; private set; }
        public static INavigationService Navigation { get; private set; }

        public static void Run()
        {
            Console.WriteLine("[BOOTSTRAP] Starting AppBootstrapper.Run()");

            var resolver = new SimpleServiceResolver();
            resolver.RegisterInstance<IServiceResolver>(resolver);

            Container = new IntegrationContainer(resolver);

            Console.WriteLine("[BOOTSTRAP] Adding modules...");

            Container.AddModule(new MediatorModule());
            Container.AddModule(new ValidationModule());
            Container.AddModule(new StorageModule());
            Container.AddModule(new MVVMModule());
            Container.AddModule(new HttpModule());
            Container.AddModule(new AppModule());

            Console.WriteLine("[BOOTSTRAP] Initializing modules...");
            Container.Initialize();

            Console.WriteLine("[BOOTSTRAP] Resolving NavigationService...");
            Navigation = Container.Resolve<INavigationService>();

            Console.WriteLine("[BOOTSTRAP] Registering views...");
            Navigation.AutoRegisterViewsWithAttributes(Assembly.GetExecutingAssembly());
            Navigation.RegisterRoutesFromViewModels(Assembly.GetExecutingAssembly());

            Console.WriteLine("[BOOTSTRAP] Finished AppBootstrapper.Run()");
        }
    }
}
